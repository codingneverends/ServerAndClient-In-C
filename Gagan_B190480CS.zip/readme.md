For plotting(plot is not correct)

server filename loclahost > rec.txt

then removed data other than time values and processed